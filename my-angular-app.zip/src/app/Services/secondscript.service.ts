import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interfaces
export interface DeliveryRequest {
  asin: string;
  pincodes: string[];
}

export interface DeliveryResult {
  pincode: string;
  deliveryDays?: number;
  error?: string;
}

export interface DeliveryResponse {
  asin: string;
  results: DeliveryResult[];
}

@Injectable({
  providedIn: 'root',
})
export class SecondscriptService {
  private apiUrl = 'http://localhost:5210/Asintool'; // Update with your .NET API URL

  constructor(private http: HttpClient) {}

  // API call to fetch delivery days
  getDeliveryDays(request: DeliveryRequest): Observable<DeliveryResponse> {
    return this.http.post<DeliveryResponse>(this.apiUrl, request, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    });
  }
}
